import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_application_1/Fruits_page.dart';
import 'package:flutter_application_1/bakery_page.dart';
import 'package:flutter_application_1/beverages_page.dart';
import 'package:flutter_application_1/chatbot/consts.dart';
import 'package:flutter_application_1/clientside/cartprovider.dart' as cart;
import 'package:flutter_application_1/clientside/darshboardclient.dart';
import 'package:flutter_application_1/dairy_page.dart';
import 'package:flutter_application_1/meat_page.dart';
import 'package:flutter_application_1/oil_page.dart';
import 'package:flutter_application_1/welcome_screen.dart';
import 'package:provider/provider.dart';
import 'package:flutter_gemini/flutter_gemini.dart';

void main() async {
  Gemini.init(apiKey: GEMINI_API_KEY);
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: "AIzaSyAhNmvLnewLN8yBy_ONnIm43mcWbddU_hQ",
      appId: "1:97782541256:android:7871ce84e07cc9f6006efd",
      messagingSenderId: "97782541256",
      projectId: "grocerry-3b9e3",
    ),
  );
  runApp(
    MultiProvider(
      providers: [ChangeNotifierProvider(create: (_) => cart.CartProvider())],
      child: const MainApp(),
    ),
  );
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      routes: {
        '/home': (context) => const ClientMarketPage(),
        '/welcome': (context) => const WelcomeScreen(),
        '/fruits': (context) => const FruitsPage(),
        '/oil': (context) => const OilPage(),
        '/meat': (context) => const MeatPage(),
        '/bakery': (context) => const BakeryPage(),
        '/dairy': (context) => const DairyPage(),
        '/beverages': (context) => const Beverages_page(),
      },
      home: WelcomeScreen(),
    );
  }
}
