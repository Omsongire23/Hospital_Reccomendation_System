import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class add extends StatefulWidget {
  final String imageUrl;
  final String name;
  final String price;
  const add({
    super.key,
    required this.imageUrl,
    required this.name,
    required this.price,
  });
  @override
  State<add> createState() => _addState();
}

class _addState extends State<add> {
  int count = 0;
  bool isColor = false;

  Future<void> addToFavorites() async {
    final productRef = FirebaseFirestore.instance.collection('favorites').doc();

    try {
      await productRef.set({
        'imageUrl': widget.imageUrl,
        'name': widget.name,
        'price': widget.price,
      });
      print('Product added to favorites!');
    } catch (e) {
      print('Error adding product to Firestore: $e');
    }
  }

  Future<void> addToCart() async {
    final productRef = FirebaseFirestore.instance.collection('cart').doc();

    try {
      await productRef.set({
        'imageUrl': widget.imageUrl,
        'name': widget.name,
        'price': widget.price,
      });
      print('Product added to favorites!');
    } catch (e) {
      print('Error adding product to Firestore: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 20.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.of(context).pop();
                    },
                    child: const Icon(
                      Icons.arrow_back_ios,
                      color: Colors.black,
                      size: 30,
                    ),
                  ),
                  const SizedBox(
                    height: 30,
                    width: 30,
                    child: Image(
                      image: AssetImage("assets/Vector.png"),
                      fit: BoxFit.contain,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 40),
            Center(
              child: SizedBox(
                height: 250,
                width: 330,
                child: Image.asset(
                  widget.imageUrl.isNotEmpty
                      ? widget.imageUrl
                      : "assets/banana.jpg",
                  fit: BoxFit.fill,
                ),
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Text(
                  widget.name,
                  style: const TextStyle(
                    fontSize: 40,
                    fontWeight: FontWeight.w600,
                    color: Colors.black,
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: () {
                    // Navigator.of(context).push(
                    //   MaterialPageRoute(
                    //     builder: (context)=> const favorite(),
                    //   ),
                    // );
                    setState(() {
                      isColor = !isColor;
                    });
                    if (isColor) {
                      addToFavorites();
                    }
                  },
                  child: Icon(
                    Icons.favorite,
                    size: 30,
                    color: isColor ? Colors.red : Colors.black,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 30),
            Row(
              children: [
                GestureDetector(
                  onTap: () {
                    count--;
                    setState(() {});
                  },
                  child: const Icon(
                    Icons.remove,
                    size: 40,
                    color: Colors.black,
                  ),
                ),
                Container(
                  height: 50,
                  width: 50,
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.black),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Center(
                    child: Text(
                      "$count",
                      style: const TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.w500,
                        color: Colors.black,
                      ),
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    count++;
                    setState(() {});
                  },
                  child: const Icon(Icons.add, size: 40, color: Colors.black),
                ),
                const Spacer(),
                Text(
                  widget.price,
                  style: const TextStyle(
                    fontSize: 40,
                    color: Colors.black,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            const Divider(color: Colors.grey, thickness: 0.4),
            const Text(
              "Product Details",
              style: TextStyle(
                fontSize: 20,
                color: Colors.black,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              "Apples are nutritious. Apples may be good for weight loss. apples may be good for your heart. As part of a healtful and varied diet.",
              style: GoogleFonts.dmSans(
                color: const Color.fromARGB(255, 94, 92, 92),
                fontSize: 16,
                fontWeight: FontWeight.w400,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been 1500s, but also the leap into electronic typesetting, remaining essentially unchanged",
              style: GoogleFonts.dmSans(
                color: const Color.fromARGB(255, 94, 92, 92),
                fontSize: 16,
                fontWeight: FontWeight.w400,
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                addToCart();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text("Added Successfully to the Cart!"),
                    duration: Duration(seconds: 2),
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                fixedSize: const Size(500, 80),
              ),
              child: const Text(
                "Add To Basket",
                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.w500,
                  color: Colors.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
