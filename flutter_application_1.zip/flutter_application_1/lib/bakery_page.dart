import 'package:flutter/material.dart';

class BakeryPage extends StatefulWidget {
  const BakeryPage({super.key});

  @override
  State<BakeryPage> createState() => _BakeryPageState();
}

class _BakeryPageState extends State<BakeryPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}