import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_application_1/screen1.dart';
import 'package:google_fonts/google_fonts.dart';

class Confim_page extends StatefulWidget {
  const Confim_page({super.key});

  @override
  State<Confim_page> createState() => _Confim_pageState();
}

class _Confim_pageState extends State<Confim_page> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: 200,
                  height: 200,
                  child: const Image(
                    image: AssetImage("assets/confirm.png"),
                    fit: BoxFit.cover,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 50),
            Text(
              "Your Order has been accepted",
              style: GoogleFonts.dmSans(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            Text(
              "Your items have been placed and are on their way to being processed",
              style: GoogleFonts.dmSans(
                fontSize: 20,
                color: Color.fromARGB(255, 119, 118, 118),
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 120),
            GestureDetector(
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder:
                        (context) => FruitMarketScreen(
                          email: FirebaseAuth.instance.currentUser!.email!,
                        ),
                  ),
                );
              },
              child: Text(
                "Back to home",
                style: GoogleFonts.dmSans(
                  color: Colors.black,
                  fontSize: 25,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
