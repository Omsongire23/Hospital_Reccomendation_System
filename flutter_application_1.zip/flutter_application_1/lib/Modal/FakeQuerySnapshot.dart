import 'package:cloud_firestore/cloud_firestore.dart';

class FakeQuerySnapshot extends QuerySnapshot {
  @override
  final List<QueryDocumentSnapshot> docs;

  FakeQuerySnapshot(this.docs);

  @override
  List<QueryDocumentSnapshot> get documents => docs;

  @override
  int get size => docs.length;

  @override
  SnapshotMetadata get metadata => throw UnimplementedError();

  @override
  List<DocumentChange> get docChanges => throw UnimplementedError();
}
