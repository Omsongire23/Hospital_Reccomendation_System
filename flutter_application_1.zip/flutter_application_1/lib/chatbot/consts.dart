const String GEMINI_API_KEY = 'AIzaSyCRgLpeSemGtvevooMXERn2iC9KOVsgBgE';
