

import 'package:flutter/material.dart';

class Category {
  final String name;
  final String image;
  final Color color;
  final String route;
  Category({required this.name, required this.image, required this.color,required this.route});
}

// List of categories
final List<Category> categories = [
  Category(
      name: "Fresh Fruits & Vegetable",
      image: "assets/vegetables.png",
      color: Colors.green[100]!,
      route: "/fruits"
    ),
      
  Category(
      name: "Cooking Oil & Ghee",
      image: "assets/oil.png",
      color: Colors.yellow[100]!,
      route: "/oil"
  ),
  Category(
      name: "Meat & Fish",
      image: "assets/meat.png",
      color: Colors.red[100]!,
      route: "/meat"
    ),
  Category(
      name: "Bakery & Snacks",
      image: "assets/bakery.png",
      color: Colors.purple[100]!,
       route: "/bakery"
  ),
  Category(
      name: "Dairy & Eggs",
      image: "assets/egg.png",
      color: Colors.orange[100]!,
      route: "/dairy"
  ),
  Category(
      name: "Beverages",
      image: "assets/coldrinks.png",
      color: Colors.blue[100]!,
      route: "/beverages"
  ),
];

