class Beverages {
  final String name;
  final String volume;
  final String image;
  final String price;

  Beverages({
    required this.name,
    required this.volume,
    required this.image,
    required this.price,
  });
}

final List<Map<String, dynamic>> beverages = [
  {
    "name": "Diet Coke",
    "volume": "355ml",
    "price": "\$1.99",
    "image": "assets/diet_coke.png",
  },
  {
    "name": "Sprite Can",
    "volume": "325ml",
    "price": "\$1.50",
    "image": "assets/sprite.png",
  },
  {
    "name": "Apple & Grape Juice",
    "volume": "2L",
    "price": "\$15.99",
    "image": "assets/apple_juice.png",
  },
  {
    "name": "Orange Juice",
    "volume": "2L",
    "price": "\$15.99",
    "image": "assets/tropicana.png",
  },
  {
    "name": "Coca Cola Can",
    "volume": "325ml",
    "price": "\$4.99",
    "image": "assets/cocacola.png",
  },
  {
    "name": "Pepsi Can",
    "volume": "330ml",
    "price": "\$4.99",
    "image": "assets/pepsi.png",
  },
];
