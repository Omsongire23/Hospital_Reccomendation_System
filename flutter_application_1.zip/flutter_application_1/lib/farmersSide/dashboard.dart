import 'dart:convert';
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_application_1/clientside/order.dart';
import 'package:flutter_application_1/clientside/wallet.dart';
import 'package:flutter_application_1/orders/order_screen1.dart';
import 'package:flutter_application_1/profile/clientProfile.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';

class FarmerMarketScreen extends StatefulWidget {
  final String email;
  const FarmerMarketScreen({super.key, required this.email});

  @override
  State<FarmerMarketScreen> createState() => _FarmerMarketScreenState();
}

class _FarmerMarketScreenState extends State<FarmerMarketScreen> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final TextEditingController _newCategoryController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();
  final TextEditingController _imageController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _quantityController = TextEditingController();
  final TextEditingController _unitController = TextEditingController(text: 'kg');
  final TextEditingController _trackingController = TextEditingController();

  String? _selectedCategory;
  List<Map<String, dynamic>> _storyItems = [];
  late Stream<QuerySnapshot> _productsStream;
  Widget _currentScreen = Container();
  String _currentTitle = 'Farmers Market';
  Map<String, double> apiPrices = {};
  File? _selectedImage;

  @override
  void initState() {
    super.initState();
    _loadStories();
    _productsStream = _createAllProductsStream();
    _currentScreen = _buildProductsScreen();
    fetchProductPrices();
  }

  @override
  void dispose() {
    _newCategoryController.dispose();
    _nameController.dispose();
    _priceController.dispose();
    _imageController.dispose();
    _descriptionController.dispose();
    _quantityController.dispose();
    _unitController.dispose();
    _trackingController.dispose();
    super.dispose();
  }

  Future<void> fetchProductPrices() async {
    try {
      print('Fetching product prices from API...');
      final response = await http.get(Uri.parse('https://www.fruityvice.com/api/fruit/all'));
      if (response.statusCode == 200) {
        List<dynamic> fruitData = jsonDecode(response.body);
        setState(() {
          apiPrices = {
            for (var fruit in fruitData)
              (fruit['name'] as String).toLowerCase(): _getMockPrice(fruit['name']),
            'carrot': _getMockPrice('carrot'),
            'potato': _getMockPrice('potato'),
            'tomato': _getMockPrice('tomato'),
            'cucumber': _getMockPrice('cucumber'),
            'spinach': _getMockPrice('spinach'),
          };
          print('Fetched prices for ${apiPrices.length} items');
        });
      } else {
        print('API Error: ${response.statusCode}');
      }
    } catch (e) {
      print('Error fetching prices: $e');
    }
  }

  double _getMockPrice(String name) {
    name = name.toLowerCase();
    if (name == 'banana') return 50.00;
    if (name == 'mango') return 150.00;
    return (30 + (DateTime.now().millisecondsSinceEpoch % 100) * 2).toDouble();
  }

  Future<void> _pickImage() async {
    final status = await Permission.photos.request();
    if (!status.isGranted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Permission denied to access photos')),
      );
      return;
    }

    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 70,
    );

    if (pickedFile != null) {
      final bytes = await File(pickedFile.path).readAsBytes();
      final base64Image = 'data:image/jpeg;base64,${base64Encode(bytes)}';
      setState(() {
        _selectedImage = File(pickedFile.path);
        _imageController.text = base64Image;
      });
    }
  }

  Stream<QuerySnapshot> _createAllProductsStream() {
    if (_selectedCategory != null) {
      return _firestore
          .collection('categories')
          .doc(_selectedCategory!.toLowerCase())
          .collection('products')
          .snapshots();
    } else {
      return _firestore.collectionGroup('products').snapshots();
    }
  }

  Future<void> _loadStories() async {
    try {
      final snapshot = await _firestore.collection('featuredItems').limit(10).get();
      setState(() {
        _storyItems = snapshot.docs.map((doc) {
          final data = doc.data();
          return {
            'id': doc.id,
            'imageUrl': data['imageUrl'] ?? 'https://via.placeholder.com/150',
            'title': data['title'] ?? 'Featured',
            'farmerName': data['farmerName'] ?? 'Local Farmer',
          };
        }).toList();
      });
    } catch (e) {
      setState(() {
        _storyItems = List.generate(
          6,
              (index) => {
            'id': 'default_$index',
            'imageUrl': 'https://picsum.photos/200/300?random=$index',
            'title': 'Seasonal Offer',
            'farmerName': 'Farmer ${index + 1}',
          },
        );
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: _buildCurvedAppBar(),
      drawer: _buildDrawer(),
      body: _currentScreen,
    );
  }

  PreferredSizeWidget _buildCurvedAppBar() {
    return PreferredSize(
      preferredSize: const Size.fromHeight(180.0),
      child: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        flexibleSpace: ClipPath(
          clipper: _CurvedAppBarClipper(),
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Colors.green.shade700,
                  Colors.green.shade500,
                  Colors.green.shade400,
                ],
              ),
            ),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(height: kToolbarHeight),
                  Text(
                    _currentTitle,
                    style: GoogleFonts.dmSans(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 8),
                  if (_currentTitle == 'Farmers Market')
                    Text(
                      'Fresh from local farms',
                      style: GoogleFonts.dmSans(
                        fontSize: 16,
                        color: Colors.white.withOpacity(0.9),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
        actions: [
          if (_currentTitle == 'Farmers Market')
            Padding(
              padding: const EdgeInsets.only(right: 16.0),
              child: IconButton(
                icon: const Icon(Icons.add, color: Colors.white, size: 30),
                onPressed: _showCategorySelection,
                tooltip: 'Add Product',
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.green.shade700, Colors.green.shade400],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const CircleAvatar(
                  radius: 30,
                  backgroundColor: Colors.white,
                  child: Icon(Icons.person, size: 40, color: Colors.green),
                ),
                const SizedBox(height: 10),
                Text(
                  'Farmer Dashboard',
                  style: GoogleFonts.dmSans(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  widget.email,
                  style: GoogleFonts.dmSans(
                    color: Colors.white.withOpacity(0.8),
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
          ListTile(
            leading: const Icon(Icons.shopping_basket, color: Colors.green),
            title: Text('Products', style: GoogleFonts.dmSans()),
            onTap: () {
              Navigator.pop(context);
              setState(() {
                _currentScreen = _buildProductsScreen();
                _currentTitle = 'Farmers Market';
              });
            },
          ),
          ListTile(
            leading: const Icon(Icons.receipt_long, color: Colors.green),
            title: Text('Orders', style: GoogleFonts.dmSans()),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const OrderView()),
              );
            },
          ),
          ListTile(
            leading: const Icon(Icons.person, color: Colors.green),
            title: Text('Profile', style: GoogleFonts.dmSans()),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const clientProfilePage()),
              );
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.logout, color: Colors.red),
            title: Text('Logout', style: GoogleFonts.dmSans(color: Colors.red)),
            onTap: () {
              Navigator.pushNamed(context, '/welcome');
            },
          ),
        ],
      ),
    );
  }

  Widget _buildProductsScreen() {
    return SingleChildScrollView(
      child: Column(
        children: [
          const SizedBox(height: 180),
          if (_storyItems.isNotEmpty)
            Container(
              height: 110,
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 8),
                itemCount: _storyItems.length,
                itemBuilder: (context, index) {
                  final story = _storyItems[index];
                  return GestureDetector(
                    onTap: () => _showStoryDetail(story),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: Column(
                        children: [
                          Container(
                            width: 70,
                            height: 70,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.green, width: 2),
                            ),
                            child: ClipOval(
                              child: CachedNetworkImage(
                                imageUrl: story['imageUrl'],
                                fit: BoxFit.cover,
                                placeholder: (context, url) => Container(
                                  color: Colors.grey[200],
                                  child: const Center(
                                    child: CircularProgressIndicator(),
                                  ),
                                ),
                                errorWidget: (context, url, error) => const Icon(
                                  Icons.shopping_basket,
                                  color: Colors.green,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 4),
                          SizedBox(
                            width: 70,
                            child: Text(
                              story['farmerName'],
                              style: GoogleFonts.dmSans(fontSize: 12),
                              textAlign: TextAlign.center,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          SizedBox(
            height: 60,
            child: StreamBuilder<QuerySnapshot>(
              stream: _firestore.collection('categories').snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Center(
                    child: Text(
                      'Error loading categories',
                      style: GoogleFonts.dmSans(color: Colors.red),
                    ),
                  );
                }
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                final categories = snapshot.data!.docs;
                if (categories.isEmpty) {
                  return Center(
                    child: TextButton(
                      onPressed: _showAddCategoryDialog,
                      child: Text(
                        '+ Add First Category',
                        style: GoogleFonts.dmSans(color: Colors.green),
                      ),
                    ),
                  );
                }
                return ListView.builder(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: categories.length + 1,
                  itemBuilder: (context, index) {
                    if (index == 0) {
                      return Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: ChoiceChip(
                          label: Text('All', style: GoogleFonts.dmSans()),
                          selected: _selectedCategory == null,
                          onSelected: (selected) {
                            setState(() {
                              _selectedCategory = null;
                              _productsStream = _createAllProductsStream();
                            });
                          },
                          selectedColor: Colors.green,
                          labelStyle: TextStyle(
                            color: _selectedCategory == null ? Colors.white : Colors.black,
                          ),
                          backgroundColor: Colors.green[50],
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                        ),
                      );
                    }
                    final category = categories[index - 1];
                    final categoryData = category.data() as Map<String, dynamic>;
                    final categoryName = categoryData['name']?.toString() ?? 'Unnamed';
                    final isSelected = _selectedCategory == categoryName;
                    return Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        label: Text(categoryName, style: GoogleFonts.dmSans()),
                        selected: isSelected,
                        onSelected: (selected) {
                          setState(() {
                            _selectedCategory = selected ? categoryName : null;
                            _productsStream = _createAllProductsStream();
                          });
                        },
                        selectedColor: Colors.green,
                        labelStyle: TextStyle(
                          color: isSelected ? Colors.white : Colors.black,
                        ),
                        backgroundColor: Colors.green[50],
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
          const SizedBox(height: 16),
          StreamBuilder<QuerySnapshot>(
            stream: _productsStream,
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                debugPrint('Products Error: ${snapshot.error}');
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.error, size: 50, color: Colors.red),
                      const SizedBox(height: 16),
                      Text(
                        'Error loading products',
                        style: GoogleFonts.dmSans(),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () => setState(() {}),
                        child: Text('Retry', style: GoogleFonts.dmSans()),
                      ),
                    ],
                  ),
                );
              }
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              List<QueryDocumentSnapshot> products = snapshot.data?.docs ?? [];
              if (products.isEmpty) {
                return Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(
                        Icons.shopping_basket,
                        size: 50,
                        color: Colors.grey,
                      ),
                      const SizedBox(height: 16),
                      Text(
                        _selectedCategory != null
                            ? 'No products in this category'
                            : 'No products available',
                        style: GoogleFonts.dmSans(),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: _showCategorySelection,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                        ),
                        child: Text(
                          'Add Product',
                          style: GoogleFonts.dmSans(color: Colors.white),
                        ),
                      ),
                    ],
                  ),
                );
              }
              return GridView.builder(
                padding: const EdgeInsets.all(16),
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  childAspectRatio: 0.75,
                ),
                itemCount: products.length,
                itemBuilder: (context, index) {
                  final doc = products[index];
                  final data = doc.data() as Map<String, dynamic>;
                  return _buildProductGridItem(doc, data);
                },
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildProductGridItem(DocumentSnapshot doc, Map<String, dynamic> data) {
    final name = (data['name'] as String?)?.toLowerCase() ?? '';
    final price = apiPrices[name] ?? (data['price'] is num ? (data['price'] as num).toDouble() : 0.00);
    final imageUrl = data['imageUrl'] as String? ?? 'assets/images/categories/default.png';
    final isBase64 = imageUrl.startsWith('data:image/');
    return GestureDetector(
      onTap: () => _showProductOptions(doc),
      child: Card(
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Hero(
                  tag: 'product-${doc.id}',
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      image: DecorationImage(
                        image: isBase64
                            ? MemoryImage(base64Decode(imageUrl.split(',').last))
                            : CachedNetworkImageProvider(imageUrl),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                data['name']?.toString() ?? 'No name',
                style: GoogleFonts.dmSans(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 4),
              Text(
                'Available: ${data['quantity']?.toString() ?? '0'} ${data['unit']?.toString() ?? ''}',
                style: GoogleFonts.dmSans(
                  fontSize: 12,
                  color: Colors.grey[600],
                ),
              ),
              const SizedBox(height: 4),
              Text(
                '₹${price.toStringAsFixed(2)}',
                style: GoogleFonts.dmSans(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.green[700],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildOrdersScreen() {
    return StreamBuilder<QuerySnapshot>(
      stream: _firestore
          .collection('orders')
          .where('farmerEmail', isEqualTo: widget.email)
          .orderBy('createdAt', descending: true)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        }
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        final orders = snapshot.data!.docs;
        if (orders.isEmpty) {
          return Center(
            child: Text(
              'No orders yet',
              style: GoogleFonts.dmSans(fontSize: 18),
            ),
          );
        }
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: orders.length,
          itemBuilder: (context, index) {
            final order = orders[index];
            final data = order.data() as Map<String, dynamic>;
            return _buildOrderCard(order, data);
          },
        );
      },
    );
  }

  Widget _buildOrderCard(DocumentSnapshot order, Map<String, dynamic> data) {
    final date = (data['createdAt'] as Timestamp).toDate();
    final formattedDate = DateFormat('MMM dd, yyyy - hh:mm a').format(date);
    final status = data['status'] ?? 'pending';
    final totalAmount = data['totalAmount'] ?? 0.0;

    Color statusColor;
    switch (status) {
      case 'accepted':
        statusColor = Colors.green;
        break;
      case 'rejected':
        statusColor = Colors.red;
        break;
      case 'shipped':
        statusColor = Colors.blue;
        break;
      case 'delivered':
        statusColor = Colors.purple;
        break;
      default:
        statusColor = Colors.orange;
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        onTap: () => _showOrderDetails(order, data),
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Order #${order.id.substring(0, 8)}',
                    style: GoogleFonts.dmSans(
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                  Chip(
                    label: Text(
                      status.toUpperCase(),
                      style: GoogleFonts.dmSans(
                        color: Colors.white,
                        fontSize: 12,
                      ),
                    ),
                    backgroundColor: statusColor,
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                formattedDate,
                style: GoogleFonts.dmSans(
                  color: Colors.grey[600],
                  fontSize: 14,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                '${data['items']?.length ?? 0} items',
                style: GoogleFonts.dmSans(fontSize: 14),
              ),
              const SizedBox(height: 8),
              Text(
                '₹${totalAmount.toStringAsFixed(2)}',
                style: GoogleFonts.dmSans(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.green[700],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showOrderDetails(DocumentSnapshot order, Map<String, dynamic> data) {
    final items = data['items'] as List<dynamic>;
    final status = data['status'] ?? 'pending';
    final customerName = data['customerName'] ?? 'Customer';
    final customerAddress = data['shippingAddress'] ?? 'No address provided';
    final customerPhone = data['customerPhone'] ?? 'No phone provided';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                'Order Details',
                style: GoogleFonts.dmSans(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              Text(
                'Customer: $customerName',
                style: GoogleFonts.dmSans(fontSize: 16),
              ),
              const SizedBox(height: 8),
              Text(
                'Phone: $customerPhone',
                style: GoogleFonts.dmSans(fontSize: 16),
              ),
              const SizedBox(height: 8),
              Text(
                'Address: $customerAddress',
                style: GoogleFonts.dmSans(fontSize: 16),
              ),
              const SizedBox(height: 16),
              const Divider(),
              Text(
                'Order Items (${items.length})',
                style: GoogleFonts.dmSans(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Flexible(
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: items.length,
                  itemBuilder: (context, index) {
                    final item = items[index] as Map<String, dynamic>;
                    final imageUrl = item['imageUrl'] as String? ?? '';
                    final isBase64 = imageUrl.startsWith('data:image/');
                    return ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: isBase64
                          ? Image.memory(
                        base64Decode(imageUrl.split(',').last),
                        width: 50,
                        height: 50,
                        fit: BoxFit.cover,
                      )
                          : CachedNetworkImage(
                        imageUrl: imageUrl,
                        width: 50,
                        height: 50,
                        fit: BoxFit.cover,
                        placeholder: (context, url) => Container(color: Colors.grey[200]),
                        errorWidget: (context, url, error) => const Icon(Icons.shopping_basket),
                      ),
                      title: Text(item['name'] ?? 'Product'),
                      subtitle: Text(
                        '${item['quantity']} ${item['unit']} × ₹${item['price']}',
                      ),
                      trailing: Text(
                        '₹${(item['quantity'] * item['price']).toStringAsFixed(2)}',
                        style: GoogleFonts.dmSans(fontWeight: FontWeight.bold),
                      ),
                    );
                  },
                ),
              ),
              const Divider(),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Total:',
                    style: GoogleFonts.dmSans(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    '₹${data['totalAmount']?.toStringAsFixed(2) ?? '0.00'}',
                    style: GoogleFonts.dmSans(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.green[700],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              if (status == 'pending')
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => _updateOrderStatus(order.id, 'rejected'),
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: Colors.red),
                          padding: const EdgeInsets.symmetric(vertical: 16),
                        ),
                        child: Text(
                          'Reject',
                          style: GoogleFonts.dmSans(color: Colors.red),
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () => _updateOrderStatus(order.id, 'accepted'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                        ),
                        child: Text(
                          'Accept',
                          style: GoogleFonts.dmSans(color: Colors.white),
                        ),
                      ),
                    ),
                  ],
                ),
              if (status == 'accepted')
                ElevatedButton(
                  onPressed: () => _showTrackingDialog(order.id),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    minimumSize: const Size(double.infinity, 50),
                  ),
                  child: Text(
                    'Add Tracking Info',
                    style: GoogleFonts.dmSans(color: Colors.white),
                  ),
                ),
              if (status == 'shipped')
                Text(
                  'Tracking: ${data['trackingNumber'] ?? 'Not provided'}',
                  style: GoogleFonts.dmSans(fontSize: 16),
                ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _updateOrderStatus(String orderId, String status) async {
    try {
      await _firestore.collection('orders').doc(orderId).update({
        'status': status,
        'updatedAt': FieldValue.serverTimestamp(),
      });
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Order $status successfully!')));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error updating order: $e')));
    }
  }

  void _showTrackingDialog(String orderId) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
          ),
          child: Container(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'Add Tracking Information',
                  style: GoogleFonts.dmSans(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: _trackingController,
                  decoration: const InputDecoration(
                    labelText: 'Tracking Number',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () async {
                    if (_trackingController.text.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Please enter tracking info'),
                        ),
                      );
                      return;
                    }
                    try {
                      await _firestore.collection('orders').doc(orderId).update({
                        'trackingNumber': _trackingController.text,
                        'status': 'shipped',
                        'shippedAt': FieldValue.serverTimestamp(),
                      });
                      _trackingController.clear();
                      Navigator.pop(context);
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Tracking info added!')),
                      );
                    } catch (e) {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    minimumSize: const Size(double.infinity, 50),
                  ),
                  child: Text(
                    'Submit',
                    style: GoogleFonts.dmSans(color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showProductOptions(DocumentSnapshot doc) {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.edit, color: Colors.blue),
                title: Text('Edit Product', style: GoogleFonts.dmSans()),
                onTap: () {
                  Navigator.pop(context);
                  _showEditProductDialog(doc);
                },
              ),
              ListTile(
                leading: const Icon(Icons.delete, color: Colors.red),
                title: Text('Delete Product', style: GoogleFonts.dmSans()),
                onTap: () {
                  Navigator.pop(context);
                  _deleteProduct(doc);
                },
              ),
              const SizedBox(height: 8),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text('Cancel', style: GoogleFonts.dmSans()),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showStoryDetail(Map<String, dynamic> story) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(story['title'], style: GoogleFonts.dmSans()),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: CachedNetworkImage(
                imageUrl: story['imageUrl'],
                height: 200,
                fit: BoxFit.cover,
                placeholder: (context, url) => Container(
                  height: 200,
                  color: Colors.grey[200],
                  child: const Center(
                    child: CircularProgressIndicator(),
                  ),
                ),
                errorWidget: (context, url, error) => Container(
                  height: 200,
                  color: Colors.grey[200],
                  child: const Icon(
                    Icons.shopping_basket,
                    size: 50,
                    color: Colors.green,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'From: ${story['farmerName']}',
              style: GoogleFonts.dmSans(fontWeight: FontWeight.bold),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close', style: GoogleFonts.dmSans()),
          ),
        ],
      ),
    );
  }

  Future<void> _addNewCategory() async {
    if (_newCategoryController.text.isEmpty) return;
    try {
      await _firestore
          .collection('categories')
          .doc(_newCategoryController.text.trim().toLowerCase())
          .set({
        'name': _newCategoryController.text.trim(),
        'createdBy': widget.email,
        'createdAt': FieldValue.serverTimestamp(),
      });
      if (!mounted) return;
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Category added successfully!')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error adding category: $e')));
    }
  }

  Future<void> _showAddCategoryDialog() async {
    _newCategoryController.clear();
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Add New Category', style: GoogleFonts.dmSans()),
        content: TextField(
          controller: _newCategoryController,
          decoration: InputDecoration(
            labelText: 'Category Name',
            labelStyle: GoogleFonts.dmSans(),
            border: const OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: GoogleFonts.dmSans()),
          ),
          ElevatedButton(
            onPressed: _addNewCategory,
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
            child: Text(
              'Add',
              style: GoogleFonts.dmSans(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _showCategorySelection() async {
    final selectedCategory = await showDialog<String>(
      context: context,
      builder: (context) => Dialog(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Select Category',
                style: GoogleFonts.dmSans(fontSize: 20),
              ),
              const SizedBox(height: 16),
              StreamBuilder<QuerySnapshot>(
                stream: _firestore.collection('categories').snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.hasError) {
                    return Text('Error: ${snapshot.error}');
                  }
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const CircularProgressIndicator();
                  }
                  final categories = snapshot.data!.docs;
                  return GridView.builder(
                    shrinkWrap: true,
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      crossAxisSpacing: 8,
                      mainAxisSpacing: 8,
                      childAspectRatio: 1.2,
                    ),
                    itemCount: categories.length + 1,
                    itemBuilder: (context, index) {
                      if (index == categories.length) {
                        return InkWell(
                          onTap: () {
                            Navigator.pop(context);
                            _showAddCategoryDialog();
                          },
                          child: Card(
                            color: Colors.green[50],
                            child: const Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.add, size: 30),
                                Text('Add New'),
                              ],
                            ),
                          ),
                        );
                      }
                      final category = categories[index];
                      final categoryData = category.data() as Map<String, dynamic>;
                      return InkWell(
                        onTap: () => Navigator.pop(context, categoryData['name']),
                        child: Card(
                          color: Colors.green[50],
                          child: Center(
                            child: Text(
                              categoryData['name']?.toString() ?? 'Unnamed',
                              style: GoogleFonts.dmSans(
                                fontWeight: FontWeight.bold,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
    if (selectedCategory != null) {
      setState(() {
        _selectedCategory = selectedCategory;
      });
      _showAddProductDialog(selectedCategory);
    }
  }

  Future<void> _showAddProductDialog(String category) async {
    _nameController.clear();
    _priceController.clear();
    _imageController.clear();
    _descriptionController.clear();
    _quantityController.clear();
    _unitController.text = 'kg';
    setState(() {
      _selectedImage = null;
    });

    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Add Product to $category',
          style: GoogleFonts.dmSans(),
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _nameController,
                decoration: InputDecoration(
                  labelText: 'Product Name',
                  labelStyle: GoogleFonts.dmSans(),
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _priceController,
                      decoration: InputDecoration(
                        labelText: 'Price',
                        labelStyle: GoogleFonts.dmSans(),
                      ),
                      keyboardType: TextInputType.number,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: TextField(
                      controller: _unitController,
                      decoration: InputDecoration(
                        labelText: 'Unit',
                        labelStyle: GoogleFonts.dmSans(),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _quantityController,
                decoration: InputDecoration(
                  labelText: 'Quantity',
                  labelStyle: GoogleFonts.dmSans(),
                ),
                keyboardType: TextInputType.number,
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _pickImage,
                      icon: const Icon(Icons.image),
                      label: Text(
                        _selectedImage == null ? 'Pick Image' : 'Image Selected',
                        style: GoogleFonts.dmSans(),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green[100],
                      ),
                    ),
                  ),
                  if (_selectedImage != null)
                    Padding(
                      padding: const EdgeInsets.only(left: 8),
                      child: Image.file(
                        _selectedImage!,
                        width: 50,
                        height: 50,
                        fit: BoxFit.cover,
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _descriptionController,
                decoration: InputDecoration(
                  labelText: 'Description',
                  labelStyle: GoogleFonts.dmSans(),
                ),
                maxLines: 2,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: GoogleFonts.dmSans()),
          ),
          ElevatedButton(
            onPressed: () async {
               if(_nameController.text.isEmpty || _priceController.text.isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
              content: Text('Please fill required fields'),
              ),
              );
              return;
              }
              try {
              await _firestore
                  .collection('categories')
                  .doc(category.toLowerCase())
                  .collection('products')
                  .add({
              'name': _nameController.text,
              'price': double.tryParse(_priceController.text) ?? 0.0,
              'unit': _unitController.text,
              'quantity': int.tryParse(_quantityController.text) ?? 1,
              'imageUrl': _imageController.text.isNotEmpty
              ? _imageController.text
                  : 'assets/default_product.png',
              'description': _descriptionController.text,
              'category': category,
              'createdAt': FieldValue.serverTimestamp(),
              'isAvailable': true,
              'updatedAt': FieldValue.serverTimestamp(),
              });
              if (!mounted) return;
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
              content: Text('Product added successfully!'),
              ),
              );
              } catch (e) {
              if (!mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Error: ${e.toString()}')),
              );
              }
            },
            child: Text(
              'Add',
              style: GoogleFonts.dmSans(color: Colors.white),
            ),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
          ),
        ],
      ),
    );
  }

  Future<void> _showEditProductDialog(DocumentSnapshot doc) async {
    final data = doc.data()! as Map<String, dynamic>;
    _nameController.text = data['name']?.toString() ?? '';
    _priceController.text = data['price']?.toString() ?? '0.0';
    _imageController.text = data['imageUrl']?.toString() ?? '';
    _descriptionController.text = data['description']?.toString() ?? '';
    _quantityController.text = data['quantity']?.toString() ?? '1';
    _unitController.text = data['unit']?.toString() ?? 'kg';
    setState(() {
      _selectedImage = null;
    });

    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Edit Product', style: GoogleFonts.dmSans()),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _nameController,
                decoration: InputDecoration(
                  labelText: 'Product Name',
                  labelStyle: GoogleFonts.dmSans(),
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _priceController,
                      decoration: InputDecoration(
                        labelText: 'Price',
                        labelStyle: GoogleFonts.dmSans(),
                      ),
                      keyboardType: TextInputType.number,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: TextField(
                      controller: _unitController,
                      decoration: InputDecoration(
                        labelText: 'Unit',
                        labelStyle: GoogleFonts.dmSans(),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _quantityController,
                decoration: InputDecoration(
                  labelText: 'Quantity',
                  labelStyle: GoogleFonts.dmSans(),
                ),
                keyboardType: TextInputType.number,
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _pickImage,
                      icon: const Icon(Icons.image),
                      label: Text(
                        _selectedImage == null ? 'Pick Image' : 'Image Selected',
                        style: GoogleFonts.dmSans(),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green[100],
                      ),
                    ),
                  ),
                  if (_selectedImage != null)
                    Padding(
                      padding: const EdgeInsets.only(left: 8),
                      child: Image.file(
                        _selectedImage!,
                        width: 50,
                        height: 50,
                        fit: BoxFit.cover,
                      ),
                    )
                  else if (_imageController.text.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(left: 8),
                      child: _imageController.text.startsWith('data:image/')
                          ? Image.memory(
                        base64Decode(_imageController.text.split(',').last),
                        width: 50,
                        height: 50,
                        fit: BoxFit.cover,
                      )
                          : CachedNetworkImage(
                        imageUrl: _imageController.text,
                        width: 50,
                        height: 50,
                        fit: BoxFit.cover,
                        errorWidget: (context, url, error) => const Icon(Icons.error),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _descriptionController,
                decoration: InputDecoration(
                  labelText: 'Description',
                  labelStyle: GoogleFonts.dmSans(),
                ),
                maxLines: 2,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: GoogleFonts.dmSans()),
          ),
          ElevatedButton(
            onPressed: () async {
              try {
                await doc.reference.update({
                  'name': _nameController.text,
                  'price': double.tryParse(_priceController.text) ?? 0.0,
                  'unit': _unitController.text,
                  'quantity': int.tryParse(_quantityController.text) ?? 1,
                  'imageUrl': _imageController.text.isNotEmpty
                      ? _imageController.text
                      : 'assets/images/categories/default_product.png',
                  'description': _descriptionController.text,
                  'updatedAt': FieldValue.serverTimestamp(),
                });
                if (!mounted) return;
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Product updated successfully!'),
                  ),
                );
              } catch (e) {
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Error: ${e.toString()}')),
                );
              }
            },
            child: Text(
              'Update',
              style: GoogleFonts.dmSans(color: Colors.white),
            ),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteProduct(DocumentSnapshot doc) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Confirm Delete', style: GoogleFonts.dmSans()),
        content: Text(
          'Are you sure you want to delete this product?',
          style: GoogleFonts.dmSans(),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('Cancel', style: GoogleFonts.dmSans()),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
            ),
            child: Text(
              'Delete',
              style: GoogleFonts.dmSans(color: Colors.white),
            ),
          ),
        ],
      ),
    ) ?? false;
    if (confirm) {
      try {
        await doc.reference.delete();
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Product deleted successfully')),
        );
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error deleting: ${e.toString()}')),
        );
      }
    }
  }

  Widget _buildWalletScreen() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.account_balance_wallet, size: 60, color: Colors.green),
          const SizedBox(height: 20),
          Text(
            'Wallet Balance',
            style: GoogleFonts.dmSans(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 10),
          StreamBuilder<DocumentSnapshot>(
            stream: _firestore.collection('farmers').doc(widget.email).snapshots(),
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                final data = snapshot.data!.data() as Map<String, dynamic>?;
                final balance = data?['walletBalance']?.toStringAsFixed(2) ?? '0.00';
                return Text(
                  '₹$balance',
                  style: GoogleFonts.dmSans(fontSize: 36, color: Colors.green),
                );
              }
              return const CircularProgressIndicator();
            },
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              // TODO: Implement withdraw functionality
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Withdraw functionality not implemented yet')),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green,
              padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
            ),
            child: Text(
              'Withdraw Funds',
              style: GoogleFonts.dmSans(fontSize: 16, color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileScreen() {
    return StreamBuilder<DocumentSnapshot>(
      stream: _firestore.collection('farmers').doc(widget.email).snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final data = snapshot.data!.data() as Map<String, dynamic>?;
        final name = data?['name'] ?? 'Farmer';
        final phone = data?['phone'] ?? 'Not provided';
        final address = data?['address'] ?? 'Not provided';
        return SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              const CircleAvatar(
                radius: 60,
                child: Icon(Icons.person, size: 60, color: Colors.green),
              ),
              const SizedBox(height: 20),
              Text(
                name,
                style: GoogleFonts.dmSans(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                widget.email,
                style: GoogleFonts.dmSans(fontSize: 16, color: Colors.grey),
              ),
              const SizedBox(height: 30),
              _buildProfileItem(Icons.phone, 'Phone', phone),
              _buildProfileItem(Icons.location_on, 'Address', address),
              const SizedBox(height: 30),
              ElevatedButton(
                onPressed: () {
                  // TODO: Implement edit profile functionality
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Edit profile functionality not implemented yet')),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                ),
                child: Text(
                  'Edit Profile',
                  style: GoogleFonts.dmSans(fontSize: 18, color: Colors.white),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildProfileItem(IconData icon, String label, String value) {
    return Container(
      margin: const EdgeInsets.only(bottom: 15),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          Icon(icon, color: Colors.green),
          const SizedBox(width: 15),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: GoogleFonts.dmSans(fontSize: 14, color: Colors.grey),
              ),
              Text(
                value,
                style: GoogleFonts.dmSans(fontSize: 16),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _CurvedAppBarClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();
    path.lineTo(0, size.height - 40);
    path.quadraticBezierTo(
      size.width / 2,
      size.height,
      size.width,
      size.height - 40,
    );
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}