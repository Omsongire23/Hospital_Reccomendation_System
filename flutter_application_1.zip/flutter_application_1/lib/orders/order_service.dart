import 'package:cloud_firestore/cloud_firestore.dart';

class OrderService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Stream<List<Map<String, dynamic>>> getOrders(String userId) {
    return _firestore
        .collection('orders')
        .where('userId', isEqualTo: userId)
        .orderBy('date', descending: true)
        .snapshots()
        .map(
          (snapshot) =>
              snapshot.docs.map((doc) {
                final data = doc.data();
                return {'id': doc.id, ...data};
              }).toList(),
        );
  }

  Future<void> updateOrderStatus(String orderId, String newStatus) async {
    await _firestore.collection('orders').doc(orderId).update({
      'status': newStatus,
      'lastUpdated': FieldValue.serverTimestamp(),
    });
  }

  Future<void> updateTrackingDetails(String orderId, String details) async {
    await _firestore.collection('orders').doc(orderId).update({
      'trackingDetails': details,
      'lastUpdated': FieldValue.serverTimestamp(),
    });
  }
}
