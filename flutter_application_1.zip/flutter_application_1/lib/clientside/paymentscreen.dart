import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:flutter_application_1/clientside/cartprovider.dart';
import 'order_success_screen.dart';

class RazorpayPaymentScreen extends StatefulWidget {
  final double price;
  final String deliverySpeed;
  final List<CartItem> cartItems;

  const RazorpayPaymentScreen({
    super.key,
    required this.price,
    required this.deliverySpeed,
    required this.cartItems,
  });

  @override
  State<RazorpayPaymentScreen> createState() => _RazorpayPaymentScreenState();
}

class _RazorpayPaymentScreenState extends State<RazorpayPaymentScreen> {
  late Razorpay _razorpay;
  bool _isProcessing = true;

  @override
  void initState() {
    super.initState();
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
    _openPaymentGateway();
  }

  void _openPaymentGateway() {
    var options = {
      'key': 'rzp_test_cXJvckaWoN0JQx', // Replace with your Razorpay key
      'amount': (widget.price * 100).toInt(), // Convert to paise
      'currency': 'INR',
      'name': 'Your App Name',
      'description': 'Order Payment',
      'prefill': {'contact': '9999999999', 'email': 'user@example.com'},
      'theme': {'color': '#0f9d58'},
    };
    _razorpay.open(options);
  }

  Future<void> _handlePaymentSuccess(PaymentSuccessResponse response) async {
    final cartProvider = Provider.of<CartProvider>(context, listen: false);

    // Prepare order items data
    final orderItems =
        widget.cartItems
            .map(
              (item) => {
                'productId': item.productId,
                'name': item.name,
                'image': item.image,
                'price': item.price,
                'quantity': item.quantity,
                'unit': item.unit,
              },
            )
            .toList();

    // Order details to save in Firebase
    final orderData = {
      'paymentId': response.paymentId,
      'amount': widget.price,
      'deliverySpeed': widget.deliverySpeed,
      'deliveryCharge': widget.deliverySpeed == 'fast' ? 50.0 : 0.0,
      'items': orderItems,
      'timestamp': FieldValue.serverTimestamp(),
      'status': 'pending',
      'userId': cartProvider.userId,
    };

    try {
      // Save order to Firestore
      final orderRef = await FirebaseFirestore.instance
          .collection('orders')
          .add(orderData);

      // Clear the cart after successful order
      await cartProvider.clear();

      // Navigate to the success page
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder:
              (context) => OrderSuccessScreen(
                paymentId: response.paymentId!,
                amount: widget.price,
                cartItems:
                    widget.cartItems
                        .map(
                          (item) => {
                            'productId': item.productId,
                            'name': item.name,
                            'image': item.image,
                            'price': item.price,
                            'quantity': item.quantity,
                            'unit': item.unit,
                          },
                        )
                        .toList(),
                deliverySpeed: widget.deliverySpeed,
              ),
        ),
      );
    } catch (error) {
      setState(() => _isProcessing = false);
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error saving order: $error')));
    }
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    setState(() => _isProcessing = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Payment Failed: ${response.message ?? 'Unknown error'}'),
      ),
    );
    Navigator.pop(context);
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('External Wallet Selected: ${response.walletName}'),
      ),
    );
  }

  @override
  void dispose() {
    _razorpay.clear();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Payment Processing'),
        automaticallyImplyLeading: false,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (_isProcessing) ...[
              CircularProgressIndicator(),
              SizedBox(height: 20),
              Text(
                'Processing your payment...',
                style: TextStyle(fontSize: 16),
              ),
            ] else ...[
              Icon(Icons.error, color: Colors.red, size: 50),
              SizedBox(height: 20),
              Text(
                'Payment failed. Please try again.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  setState(() => _isProcessing = true);
                  _openPaymentGateway();
                },
                child: Text('Retry Payment'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text('Go Back'),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
