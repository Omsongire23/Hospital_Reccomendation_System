class ImageMap {
  static const Map<String, String> categories = {
    "fruits": "assets/images/categories/fruits.png",
    "fertilizers": "assets/images/categories/fertilizers.png",
    "vegetables": "assets/images/categories/vegetables.png",
    "roots": "assets/images/categories/roots.png",
    "equiptments": "assets/images/categories/equiptments.png",
  };

  static const Map<String, String> products = {
    "fruits": "assets/images/categories/fruits.png",
    "fertilizers": "assets/images/categories/fertilizers.png",
    "vegetables": "assets/images/categories/vegetables.png",
    "roots": "assets/images/categories/roots.png",
    "equiptments": "assets/images/categories/equiptments.png",
  };

  static const String defaultImage = "assets/images/categories/default.png";

  static String getCategoryImage(String name) {
    return categories[name] ?? defaultImage;
  }

  static String getProductImage(String name) {
    return products[name] ?? defaultImage;
  }
}
