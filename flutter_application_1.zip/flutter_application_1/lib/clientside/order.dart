import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class OrderView extends StatefulWidget {
  const OrderView({super.key});

  @override
  _OrderViewState createState() => _OrderViewState();
}

class _OrderViewState extends State<OrderView> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Manage Orders'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => setState(() {}),
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream:
            _firestore
                .collection('orders')
                .orderBy('timestamp', descending: true)
                .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final orders = snapshot.data!.docs;
          if (orders.isEmpty) {
            return const Center(child: Text('No orders found'));
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: orders.length,
            itemBuilder: (context, index) {
              final order = orders[index];
              final data = order.data() as Map<String, dynamic>;
              final currentStatus =
                  data['status']?.toString().toLowerCase() ?? 'pending';
              final deliverySpeed =
                  data['deliverySpeed']?.toString() ?? 'normal';
              final deliveryCharge = data['deliveryCharge']?.toDouble() ?? 0.0;
              final timestamp = data['timestamp'] as Timestamp?;
              final orderDate = timestamp?.toDate();
              final feedback = data['feedback'] as Map<String, dynamic>?;

              return OrderCard(
                order: order,
                data: data,
                onStatusUpdate:
                    (newStatus) => _updateOrderStatus(order.id, newStatus),
                currentStatus: currentStatus,
                deliverySpeed: deliverySpeed,
                deliveryCharge: deliveryCharge,
                orderDate: orderDate,
                feedback: feedback,
              );
            },
          );
        },
      ),
    );
  }

  Future<void> _updateOrderStatus(String orderId, String newStatus) async {
    try {
      final now = Timestamp.now();

      await _firestore.collection('orders').doc(orderId).update({
        'status': newStatus,
        'lastUpdated': now,
        'statusHistory': FieldValue.arrayUnion([
          {'status': newStatus, 'updatedAt': now},
        ]),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Order status updated to $newStatus')),
      );
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Failed to update status: $e')));
    }
  }
}

class OrderCard extends StatelessWidget {
  final DocumentSnapshot order;
  final Map<String, dynamic> data;
  final Function(String) onStatusUpdate;
  final String currentStatus;
  final String deliverySpeed;
  final double deliveryCharge;
  final DateTime? orderDate;
  final Map<String, dynamic>? feedback;

  const OrderCard({
    super.key,
    required this.order,
    required this.data,
    required this.onStatusUpdate,
    required this.currentStatus,
    required this.deliverySpeed,
    required this.deliveryCharge,
    this.orderDate,
    this.feedback,
  });

  @override
  Widget build(BuildContext context) {
    final statusHistory = List<Map<String, dynamic>>.from(
      data['statusHistory'] ?? [],
    );
    statusHistory.sort(
      (a, b) =>
          (b['updatedAt'] as Timestamp).compareTo(a['updatedAt'] as Timestamp),
    );

    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Order Header Row
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Order #${order.id.substring(0, 8)}',
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                    if (orderDate != null)
                      Text(
                        DateFormat('MMM dd, hh:mm a').format(orderDate!),
                        style: TextStyle(color: Colors.grey[600], fontSize: 12),
                      ),
                  ],
                ),
                Chip(
                  label: Text(
                    currentStatus.toUpperCase(),
                    style: const TextStyle(color: Colors.white, fontSize: 12),
                  ),
                  backgroundColor: _getStatusColor(currentStatus),
                ),
              ],
            ),

            const SizedBox(height: 12),

            // Delivery Speed Indicator
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color:
                    deliverySpeed == 'fast'
                        ? Colors.orange.withOpacity(0.1)
                        : Colors.grey.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: deliverySpeed == 'fast' ? Colors.orange : Colors.grey,
                  width: 0.5,
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    deliverySpeed == 'fast'
                        ? Icons.rocket_launch
                        : Icons.schedule,
                    size: 16,
                    color:
                        deliverySpeed == 'fast' ? Colors.orange : Colors.grey,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    deliverySpeed == 'fast'
                        ? 'Fast Delivery'
                        : 'Normal Delivery',
                    style: TextStyle(
                      color:
                          deliverySpeed == 'fast' ? Colors.orange : Colors.grey,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  if (deliverySpeed == 'fast') ...[
                    const SizedBox(width: 6),
                    Text(
                      '+₹${deliveryCharge.toStringAsFixed(2)}',
                      style: TextStyle(
                        color: Colors.orange,
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ],
              ),
            ),

            const SizedBox(height: 12),

            // Order Details
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${data['items']?.length ?? 0} items',
                      style: TextStyle(color: Colors.grey[600], fontSize: 14),
                    ),
                    if (data['customerName'] != null)
                      Text(
                        'Customer: ${data['customerName']}',
                        style: TextStyle(color: Colors.grey[600], fontSize: 14),
                      ),
                  ],
                ),
                Text(
                  '₹${data['amount']?.toStringAsFixed(2) ?? '0.00'}',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.green,
                  ),
                ),
              ],
            ),

            // Client Feedback Section
            if (feedback != null) _buildFeedbackSection(feedback!),

            const SizedBox(height: 16),

            // Status Actions
            _buildStatusActions(context),

            const SizedBox(height: 16),

            // Status History
            if (statusHistory.isNotEmpty) ...[
              const Divider(),
              const SizedBox(height: 8),
              const Text(
                'Status History:',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              ...statusHistory.map(
                (history) => _buildStatusHistoryItem(history),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildFeedbackSection(Map<String, dynamic> feedback) {
    final rating = feedback['rating']?.toDouble() ?? 0.0;
    final comment = feedback['comment']?.toString() ?? '';
    final timestamp = feedback['timestamp'] as Timestamp?;
    final date = timestamp?.toDate();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 16),
        const Divider(),
        const SizedBox(height: 8),
        const Text(
          'Client Feedback:',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            ...List.generate(5, (index) {
              return Icon(
                index < rating ? Icons.star : Icons.star_border,
                color: Colors.amber,
                size: 24,
              );
            }),
            const SizedBox(width: 8),
            Text(
              rating.toStringAsFixed(1),
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        if (comment.isNotEmpty) ...[
          const SizedBox(height: 8),
          Card(
            color: Colors.grey[100],
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Text(comment, style: const TextStyle(fontSize: 14)),
            ),
          ),
        ],
        if (date != null) ...[
          const SizedBox(height: 4),
          Text(
            'Submitted on ${DateFormat('MMM dd, yyyy').format(date)}',
            style: TextStyle(color: Colors.grey[600], fontSize: 12),
          ),
        ],
      ],
    );
  }

  Widget _buildStatusActions(BuildContext context) {
    final nextStatus = _getNextStatus(currentStatus);
    final canDeny = currentStatus == 'pending';

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        if (nextStatus != null)
          ElevatedButton(
            onPressed: () => onStatusUpdate(nextStatus),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green,
              minimumSize: const Size(120, 40),
            ),
            child: const Text('Next Status'),
          ),
        if (canDeny)
          OutlinedButton(
            onPressed: () => onStatusUpdate('denied'),
            style: OutlinedButton.styleFrom(
              side: const BorderSide(color: Colors.red),
              minimumSize: const Size(120, 40),
            ),
            child: const Text('Deny', style: TextStyle(color: Colors.red)),
          ),
        if (currentStatus == 'out for delivery')
          ElevatedButton(
            onPressed: () => onStatusUpdate('delivered'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue,
              minimumSize: const Size(120, 40),
            ),
            child: const Text('Mark Delivered'),
          ),
      ],
    );
  }

  Widget _buildStatusHistoryItem(Map<String, dynamic> history) {
    final status = history['status']?.toString() ?? '';
    final timestamp = history['updatedAt'] as Timestamp?;
    final date = timestamp?.toDate();

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Container(
            width: 24,
            height: 24,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _getStatusColor(status.toLowerCase()),
            ),
            child: Icon(
              _getStatusIcon(status.toLowerCase()),
              size: 16,
              color: Colors.white,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  status.toUpperCase(),
                  style: TextStyle(
                    color: _getStatusColor(status.toLowerCase()),
                    fontWeight: FontWeight.bold,
                  ),
                ),
                if (date != null)
                  Text(
                    DateFormat('MMM dd, hh:mm a').format(date),
                    style: TextStyle(color: Colors.grey[600], fontSize: 12),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String? _getNextStatus(String current) {
    const statusFlow = [
      'pending',
      'processing',
      'shipped',
      'in transit',
      'out for delivery',
      'delivered',
    ];

    final currentIndex = statusFlow.indexOf(current);
    if (currentIndex == -1 || currentIndex >= statusFlow.length - 1) {
      return null;
    }
    return statusFlow[currentIndex + 1];
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'delivered':
        return Colors.green;
      case 'denied':
        return Colors.red;
      case 'pending':
        return Colors.orange;
      case 'processing':
        return Colors.blue;
      case 'shipped':
        return Colors.purple;
      case 'in transit':
        return Colors.indigo;
      case 'out for delivery':
        return Colors.teal;
      default:
        return Colors.grey;
    }
  }

  IconData _getStatusIcon(String status) {
    switch (status) {
      case 'delivered':
        return Icons.check_circle;
      case 'denied':
        return Icons.cancel;
      case 'pending':
        return Icons.pending;
      case 'processing':
        return Icons.autorenew;
      case 'shipped':
        return Icons.local_shipping;
      case 'in transit':
        return Icons.directions_bus;
      case 'out for delivery':
        return Icons.delivery_dining;
      default:
        return Icons.help;
    }
  }
}
