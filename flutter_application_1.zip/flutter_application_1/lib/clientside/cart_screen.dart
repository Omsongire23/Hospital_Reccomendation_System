import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_application_1/clientside/paymentscreen.dart';
import 'package:flutter_application_1/clientside/cartprovider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'image_map.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    final isSmallScreen = screenWidth < 350;

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        flexibleSpace: Container(
          decoration: BoxDecoration(color: Colors.transparent),
        ),
        actions: [
          Consumer<CartProvider>(
            builder: (context, cart, child) {
              return cart.itemCount > 0
                  ? TextButton(
                    child: Text(
                      'Clear Cart',
                      style: GoogleFonts.dmSans(
                        color: Colors.red[700],
                        fontWeight: FontWeight.bold,
                        fontSize: isSmallScreen ? 12 : 14,
                      ),
                    ),
                    onPressed: () => _showClearCartDialog(context),
                  )
                  : const SizedBox();
            },
          ),
        ],
      ),
      body: Consumer<CartProvider>(
        builder: (context, cart, child) {
          if (cart.itemCount == 0) {
            return _buildEmptyCart(context, screenWidth);
          }
          return Column(
            children: [
              Expanded(
                child: _buildCartItemsList(
                  cart,
                  Theme.of(context),
                  screenWidth,
                ),
              ),
              _buildCartSummary(cart, context, screenWidth),
            ],
          );
        },
      ),
    );
  }

  Widget _buildEmptyCart(BuildContext context, double screenWidth) {
    final isSmallScreen = screenWidth < 350;

    return Center(
      child: SingleChildScrollView(
        padding: EdgeInsets.all(isSmallScreen ? 16 : 24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.shopping_cart_outlined,
              size: isSmallScreen ? 60 : 80,
              color: Colors.grey[400],
            ),
            SizedBox(height: isSmallScreen ? 16 : 20),
            Text(
              'Your cart is empty',
              style: GoogleFonts.dmSans(
                fontSize: isSmallScreen ? 18 : 22,
                fontWeight: FontWeight.bold,
                color: Colors.grey[600],
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: isSmallScreen ? 8 : 10),
            Text(
              'Browse products and add items to your cart',
              style: GoogleFonts.dmSans(
                fontSize: isSmallScreen ? 14 : 16,
                color: Colors.grey[500],
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: isSmallScreen ? 16 : 20),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).popUntil((route) => route.isFirst);
                Navigator.of(context).pushNamed('/home');
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green[700],
                padding: EdgeInsets.symmetric(
                  horizontal: isSmallScreen ? 20 : 24,
                  vertical: isSmallScreen ? 10 : 12,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: Text(
                'Continue Shopping',
                style: GoogleFonts.dmSans(
                  fontSize: isSmallScreen ? 14 : 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCartItemsList(
    CartProvider cart,
    ThemeData theme,
    double screenWidth,
  ) {
    final isSmallScreen = screenWidth < 350;

    return ListView.separated(
      padding: EdgeInsets.all(isSmallScreen ? 12 : 16),
      itemCount: cart.itemCount,
      separatorBuilder:
          (context, index) => SizedBox(height: isSmallScreen ? 8 : 12),
      itemBuilder: (ctx, index) {
        final item = cart.items[index];
        return Dismissible(
          key: Key(item.id),
          direction: DismissDirection.endToStart,
          background: Container(
            margin: EdgeInsets.symmetric(vertical: 4),
            decoration: BoxDecoration(
              color: Colors.red[400],
              borderRadius: BorderRadius.circular(12),
            ),
            alignment: Alignment.centerRight,
            padding: const EdgeInsets.only(right: 20),
            child: Icon(
              Icons.delete_forever,
              color: Colors.white,
              size: isSmallScreen ? 24 : 28,
            ),
          ),
          onDismissed: (direction) {
            cart.removeItem(item.productId);
            ScaffoldMessenger.of(ctx).showSnackBar(
              SnackBar(
                content: Text('${item.name} removed'),
                action: SnackBarAction(
                  label: 'Undo',
                  onPressed: () {
                    cart.addItem(
                      item.productId,
                      item.name,
                      item.price,
                      item.unit,
                    );
                  },
                ),
              ),
            );
          },
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  spreadRadius: 2,
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              children: [
                ClipRRect(
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(12),
                    bottomLeft: Radius.circular(12),
                  ),
                  child: Image.asset(
                    item.image,
                    width: isSmallScreen ? 80 : 100,
                    height: isSmallScreen ? 80 : 100,
                    fit: BoxFit.cover,
                    errorBuilder:
                        (context, error, stackTrace) => Container(
                          color: Colors.grey[200],
                          width: isSmallScreen ? 80 : 100,
                          height: isSmallScreen ? 80 : 100,
                          child: Icon(Icons.image_not_supported),
                        ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.all(isSmallScreen ? 8 : 12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          item.name,
                          style: GoogleFonts.dmSans(
                            fontSize: isSmallScreen ? 14 : 16,
                            fontWeight: FontWeight.bold,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        SizedBox(height: isSmallScreen ? 2 : 4),
                        Text(
                          'Rs${item.price.toStringAsFixed(2)}/${item.unit}',
                          style: GoogleFonts.dmSans(
                            fontSize: isSmallScreen ? 12 : 14,
                            color: Colors.green[700],
                          ),
                        ),
                        SizedBox(height: isSmallScreen ? 6 : 8),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                color: Colors.grey[100],
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Row(
                                children: [
                                  IconButton(
                                    icon: Icon(
                                      Icons.remove,
                                      size: isSmallScreen ? 16 : 18,
                                    ),
                                    onPressed: () {
                                      if (item.quantity > 1) {
                                        cart.updateQuantity(
                                          item.productId,
                                          item.quantity - 1,
                                        );
                                      } else {
                                        cart.removeItem(item.productId);
                                      }
                                    },
                                  ),
                                  Text(
                                    item.quantity.toString(),
                                    style: GoogleFonts.dmSans(
                                      fontWeight: FontWeight.bold,
                                      fontSize: isSmallScreen ? 14 : 16,
                                    ),
                                  ),
                                  IconButton(
                                    icon: Icon(
                                      Icons.add,
                                      size: isSmallScreen ? 16 : 18,
                                    ),
                                    onPressed: () {
                                      cart.updateQuantity(
                                        item.productId,
                                        item.quantity + 1,
                                      );
                                    },
                                  ),
                                ],
                              ),
                            ),
                            Text(
                              'RS ${(item.totalPrice).toStringAsFixed(2)}',
                              style: GoogleFonts.dmSans(
                                fontSize: isSmallScreen ? 14 : 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildCartSummary(
    CartProvider cart,
    BuildContext context,
    double screenWidth,
  ) {
    final isSmallScreen = screenWidth < 350;

    return Container(
      padding: EdgeInsets.all(isSmallScreen ? 12 : 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(20),
          topRight: Radius.circular(20),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            spreadRadius: 2,
            blurRadius: 10,
            offset: const Offset(0, -3),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Subtotal',
                style: GoogleFonts.dmSans(
                  fontSize: isSmallScreen ? 14 : 16,
                  color: Colors.grey[600],
                ),
              ),
              Text(
                'Rs${cart.totalAmount.toStringAsFixed(2)}',
                style: GoogleFonts.dmSans(
                  fontSize: isSmallScreen ? 14 : 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          SizedBox(height: isSmallScreen ? 6 : 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Delivery',
                style: GoogleFonts.dmSans(
                  fontSize: isSmallScreen ? 14 : 16,
                  color: Colors.grey[600],
                ),
              ),
              Text(
                cart.deliverySpeed == 'fast' ? 'Rs50.00' : 'Rs0.00',
                style: GoogleFonts.dmSans(
                  fontSize: isSmallScreen ? 14 : 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          Divider(height: isSmallScreen ? 20 : 24, thickness: 1),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Total',
                style: GoogleFonts.dmSans(
                  fontSize: isSmallScreen ? 16 : 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Rs${cart.totalAmountWithDelivery.toStringAsFixed(2)}',
                style: GoogleFonts.dmSans(
                  fontSize: isSmallScreen ? 16 : 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.green[800],
                ),
              ),
            ],
          ),
          SizedBox(height: isSmallScreen ? 12 : 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green[800],
                padding: EdgeInsets.symmetric(
                  vertical: isSmallScreen ? 14 : 16,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 2,
              ),
              onPressed: () {
                _showDeliveryOptions(context, cart);
              },
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.shopping_bag_outlined,
                    color: Colors.white,
                    size: isSmallScreen ? 20 : 24,
                  ),
                  SizedBox(width: isSmallScreen ? 6 : 8),
                  Text(
                    isSmallScreen ? 'Checkout' : 'Proceed to Checkout',
                    style: GoogleFonts.dmSans(
                      fontSize: isSmallScreen ? 14 : 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showDeliveryOptions(BuildContext context, CartProvider cart) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isSmallScreen = screenWidth < 350;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        // Use StatefulBuilder to allow rebuilding just the bottom sheet
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setModalState) {
            return Container(
              padding: EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Select Delivery Option',
                    style: GoogleFonts.dmSans(
                      fontSize: isSmallScreen ? 18 : 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 20),
                  // Fast Delivery Option
                  ListTile(
                    title: Text(
                      'Fast Delivery',
                      style: GoogleFonts.dmSans(
                        fontSize: isSmallScreen ? 16 : 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    subtitle: Text(
                      'Delivery within 1 hour',
                      style: GoogleFonts.dmSans(
                        fontSize: isSmallScreen ? 14 : 16,
                      ),
                    ),
                    trailing: Text(
                      'Rs50',
                      style: GoogleFonts.dmSans(
                        fontSize: isSmallScreen ? 16 : 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.green[800],
                      ),
                    ),
                    leading: Radio<String>(
                      value: 'fast',
                      groupValue: cart.deliverySpeed,
                      onChanged: (value) {
                        setModalState(() {
                          cart.setDeliverySpeed(value!);
                        });
                      },
                    ),
                    onTap: () {
                      setModalState(() {
                        cart.setDeliverySpeed('fast');
                      });
                    },
                  ),
                  // Normal Delivery Option
                  ListTile(
                    title: Text(
                      'Normal Delivery',
                      style: GoogleFonts.dmSans(
                        fontSize: isSmallScreen ? 16 : 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    subtitle: Text(
                      'Delivery within 1-2 days',
                      style: GoogleFonts.dmSans(
                        fontSize: isSmallScreen ? 14 : 16,
                      ),
                    ),
                    trailing: Text(
                      'Free',
                      style: GoogleFonts.dmSans(
                        fontSize: isSmallScreen ? 16 : 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.green[800],
                      ),
                    ),
                    leading: Radio<String>(
                      value: 'normal',
                      groupValue: cart.deliverySpeed,
                      onChanged: (value) {
                        setModalState(() {
                          cart.setDeliverySpeed(value!);
                        });
                      },
                    ),
                    onTap: () {
                      setModalState(() {
                        cart.setDeliverySpeed('normal');
                      });
                    },
                  ),
                  SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green[800],
                        padding: EdgeInsets.symmetric(
                          vertical: isSmallScreen ? 14 : 16,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder:
                                (context) => RazorpayPaymentScreen(
                                  price: cart.totalAmountWithDelivery,
                                  deliverySpeed: cart.deliverySpeed,
                                  cartItems: cart.items,
                                ),
                          ),
                        );
                      },
                      child: Text(
                        'Proceed to Payment',
                        style: GoogleFonts.dmSans(
                          fontSize: isSmallScreen ? 14 : 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 10),
                ],
              ),
            );
          },
        );
      },
    );
  }

  void _showClearCartDialog(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isSmallScreen = screenWidth < 350;

    showDialog(
      context: context,
      builder:
          (ctx) => AlertDialog(
            title: Text(
              'Clear Cart?',
              style: GoogleFonts.dmSans(
                fontWeight: FontWeight.bold,
                fontSize: isSmallScreen ? 18 : 20,
              ),
            ),
            content: Text(
              'Are you sure you want to remove all items from your cart?',
              style: GoogleFonts.dmSans(fontSize: isSmallScreen ? 14 : 16),
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(ctx).pop(false),
                child: Text(
                  'Cancel',
                  style: GoogleFonts.dmSans(
                    color: Colors.grey[700],
                    fontSize: isSmallScreen ? 14 : 16,
                  ),
                ),
              ),
              TextButton(
                onPressed: () {
                  Provider.of<CartProvider>(context, listen: false).clear();
                  Navigator.of(ctx).pop(true);
                  ScaffoldMessenger.of(
                    context,
                  ).showSnackBar(const SnackBar(content: Text('Cart cleared')));
                },
                child: Text(
                  'Clear',
                  style: GoogleFonts.dmSans(
                    color: Colors.red[700],
                    fontWeight: FontWeight.bold,
                    fontSize: isSmallScreen ? 14 : 16,
                  ),
                ),
              ),
            ],
          ),
    );
  }
}
