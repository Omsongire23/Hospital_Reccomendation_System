import 'package:flutter/foundation.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'image_map.dart';

class CartItem {
  final String id;
  final String productId;
  final String name;
  final String image;
  final double price;
  final String unit;
  int quantity;

  CartItem({
    required this.id,
    required this.productId,
    required this.name,
    required this.image,
    required this.price,
    required this.unit,
    this.quantity = 1,
  });

  double get totalPrice => price * quantity;
}

class CartProvider with ChangeNotifier {
  final String userId;
  List<CartItem> _items = [];
  String _deliverySpeed = 'normal'; // 'normal' or 'fast'
  double _deliveryCharge = 0.0;

  CartProvider({this.userId = 'test_user'}) {
    _loadCartItems();
  }

  List<CartItem> get items => _items;
  int get itemCount => _items.length;
  double get totalAmount =>
      _items.fold(0, (sum, item) => sum + item.totalPrice);
  String get deliverySpeed => _deliverySpeed;
  double get deliveryCharge => _deliveryCharge;

  // New getter for total amount including delivery charge
  double get totalAmountWithDelivery => totalAmount + deliveryCharge;

  Future<void> _loadCartItems() async {
    try {
      final snapshot =
          await FirebaseFirestore.instance
              .collection('carts')
              .doc(userId)
              .collection('items')
              .get();

      _items =
          snapshot.docs.map((doc) {
            final data = doc.data();
            return CartItem(
              id: doc.id,
              productId: doc.id,
              name: data['name'] ?? '',
              image: data['image'] ?? ImageMap.defaultImage,
              price: (data['price'] as num).toDouble(),
              unit: data['unit'] ?? 'each',
              quantity: data['quantity'] ?? 1,
            );
          }).toList();
      notifyListeners();
    } catch (e) {
      if (kDebugMode) print('Error loading cart items: $e');
    }
  }

  // Add this method to set delivery speed
  void setDeliverySpeed(String speed) {
    _deliverySpeed = speed;
    _deliveryCharge = speed == 'fast' ? 50.0 : 0.0;
    notifyListeners();
  }

  Future<void> addItem(
    String productId,
    String name,
    double price,
    String unit,
  ) async {
    try {
      final existingIndex = _items.indexWhere(
        (item) => item.productId == productId,
      );
      final image = ImageMap.getProductImage(name);

      if (existingIndex >= 0) {
        _items[existingIndex].quantity++;
        await FirebaseFirestore.instance
            .collection('carts')
            .doc(userId)
            .collection('items')
            .doc(productId)
            .update({
              'quantity': _items[existingIndex].quantity,
              'image': image,
            });
      } else {
        final newItem = CartItem(
          id: productId,
          productId: productId,
          name: name,
          image: image,
          price: price,
          unit: unit,
          quantity: 1,
        );
        _items.add(newItem);
        await FirebaseFirestore.instance
            .collection('carts')
            .doc(userId)
            .collection('items')
            .doc(productId)
            .set({
              'name': name,
              'image': image,
              'price': price,
              'unit': unit,
              'quantity': 1,
            });
      }
      notifyListeners();
    } catch (e) {
      if (kDebugMode) print('Error adding item to cart: $e');
      rethrow;
    }
  }

  Future<void> removeItem(String productId) async {
    try {
      _items.removeWhere((item) => item.productId == productId);
      await FirebaseFirestore.instance
          .collection('carts')
          .doc(userId)
          .collection('items')
          .doc(productId)
          .delete();
      notifyListeners();
    } catch (e) {
      if (kDebugMode) print('Error removing item from cart: $e');
      rethrow;
    }
  }

  Future<void> updateQuantity(String productId, int newQuantity) async {
    try {
      final index = _items.indexWhere((item) => item.productId == productId);
      if (index >= 0) {
        _items[index].quantity = newQuantity;
        await FirebaseFirestore.instance
            .collection('carts')
            .doc(userId)
            .collection('items')
            .doc(productId)
            .update({'quantity': newQuantity});
        notifyListeners();
      }
    } catch (e) {
      if (kDebugMode) print('Error updating item quantity: $e');
      rethrow;
    }
  }

  Future<void> clear() async {
    try {
      final batch = FirebaseFirestore.instance.batch();
      final items =
          await FirebaseFirestore.instance
              .collection('carts')
              .doc(userId)
              .collection('items')
              .get();

      for (var doc in items.docs) {
        batch.delete(doc.reference);
      }
      await batch.commit();

      _items.clear();
      _deliverySpeed = 'normal'; // Reset to default
      _deliveryCharge = 0.0;
      notifyListeners();
    } catch (e) {
      if (kDebugMode) print('Error clearing cart: $e');
      rethrow;
    }
  }
}
