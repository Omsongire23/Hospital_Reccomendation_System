import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

// Define the Wallet class if not already defined
class Wallet {
  final double balance;
  final DateTime updatedAt;

  Wallet({required this.balance, required this.updatedAt});

  factory Wallet.fromMap(Map<String, dynamic> data) {
    return Wallet(
      balance: data['balance']?.toDouble() ?? 0.0,
      updatedAt: (data['updatedAt'] as Timestamp).toDate(),
    );
  }
}

class WalletTransaction {
  final String type;
  final double amount;
  final String source;
  final DateTime timestamp;
  final String status;
  final double previousBalance;
  final double newBalance;

  WalletTransaction({
    required this.type,
    required this.amount,
    required this.source,
    required this.timestamp,
    required this.status,
    required this.previousBalance,
    required this.newBalance,
  });

  factory WalletTransaction.fromDocument(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return WalletTransaction(
      type: data['type'] ?? '',
      amount: (data['amount'] ?? 0).toDouble(),
      source: data['source'] ?? '',
      timestamp: (data['timestamp'] as Timestamp).toDate(),
      status: data['status'] ?? '',
      previousBalance: (data['previousBalance'] ?? 0).toDouble(),
      newBalance: (data['newBalance'] ?? 0).toDouble(),
    );
  }
}

class WalletScreen extends StatefulWidget {
  final String userId;

  const WalletScreen({super.key, required this.userId});

  @override
  _WalletScreenState createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final NumberFormat _currencyFormat = NumberFormat.currency(symbol: '\$');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Wallet'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => setState(() {}),
          ),
        ],
      ),
      body: Column(
        children: [
          _buildBalanceCard(),
          const Divider(height: 1),
          const Padding(
            padding: EdgeInsets.all(16),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Transaction History',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
          ),
          Expanded(child: _buildTransactionList()),
        ],
      ),
    );
  }

  Widget _buildBalanceCard() {
    return StreamBuilder<DocumentSnapshot>(
      stream: _firestore.doc('users/${widget.userId}').snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Card(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Center(child: CircularProgressIndicator()),
            ),
          );
        }

        if (!snapshot.hasData || !snapshot.data!.exists) {
          return const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text('Wallet not found'),
            ),
          );
        }

        final wallet = Wallet.fromMap(
          snapshot.data!.data() as Map<String, dynamic>,
        );

        return Card(
          margin: const EdgeInsets.all(16),
          elevation: 4,
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const Text(
                  'Current Balance',
                  style: TextStyle(fontSize: 16, color: Colors.grey),
                ),
                const SizedBox(height: 8),
                Text(
                  _currencyFormat.format(wallet.balance),
                  style: const TextStyle(
                    fontSize: 36,
                    fontWeight: FontWeight.bold,
                    color: Colors.green,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Last updated: ${DateFormat('MMM d, y - h:mm a').format(wallet.updatedAt)}',
                  style: const TextStyle(fontSize: 12, color: Colors.grey),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildTransactionList() {
    return StreamBuilder<QuerySnapshot>(
      stream:
          _firestore
              .collection('users/${widget.userId}/walletHistory')
              .orderBy('timestamp', descending: true)
              .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return const Center(child: Text('No transactions yet'));
        }

        return ListView.separated(
          padding: const EdgeInsets.only(bottom: 16),
          itemCount: snapshot.data!.docs.length,
          separatorBuilder: (context, index) => const Divider(height: 1),
          itemBuilder: (context, index) {
            final transaction = WalletTransaction.fromDocument(
              snapshot.data!.docs[index],
            );

            return ListTile(
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 8,
              ),
              leading: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color:
                      transaction.type == 'credit'
                          ? Colors.green.withOpacity(0.2)
                          : Colors.red.withOpacity(0.2),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  transaction.type == 'credit'
                      ? Icons.arrow_upward
                      : Icons.arrow_downward,
                  color:
                      transaction.type == 'credit' ? Colors.green : Colors.red,
                ),
              ),
              title: Text(
                transaction.source,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                DateFormat('MMM d, y - h:mm a').format(transaction.timestamp),
              ),
              trailing: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    '${transaction.type == 'credit' ? '+' : '-'}${_currencyFormat.format(transaction.amount)}',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color:
                          transaction.type == 'credit'
                              ? Colors.green
                              : Colors.red,
                    ),
                  ),
                  Text(
                    'Balance: ${_currencyFormat.format(transaction.newBalance)}',
                    style: const TextStyle(fontSize: 12),
                  ),
                ],
              ),
              onTap: () => _showTransactionDetails(transaction),
            );
          },
        );
      },
    );
  }

  void _showTransactionDetails(WalletTransaction transaction) {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('Transaction Details'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildDetailRow('Type', transaction.type.toUpperCase()),
                _buildDetailRow(
                  'Amount',
                  '${transaction.type == 'credit' ? '+' : '-'}${_currencyFormat.format(transaction.amount)}',
                ),
                _buildDetailRow('Source', transaction.source),
                _buildDetailRow(
                  'Date',
                  DateFormat(
                    'MMMM d, y - h:mm a',
                  ).format(transaction.timestamp),
                ),
                _buildDetailRow('Status', transaction.status.toUpperCase()),
                const SizedBox(height: 16),
                _buildDetailRow(
                  'Previous Balance',
                  _currencyFormat.format(transaction.previousBalance),
                ),
                _buildDetailRow(
                  'New Balance',
                  _currencyFormat.format(transaction.newBalance),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('CLOSE'),
              ),
            ],
          ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(
            width: 120,
            child: Text(
              label,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
          Text(value),
        ],
      ),
    );
  }
}
