import 'package:flutter/material.dart';

class OilPage extends StatefulWidget {
  const OilPage({super.key});

  @override
  State<OilPage> createState() => _OilPageState();
}

class _OilPageState extends State<OilPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}