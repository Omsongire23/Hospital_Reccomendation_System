import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class FarmerProfilePage extends StatefulWidget {
  const FarmerProfilePage({super.key});
  @override
  State<FarmerProfilePage> createState() => _FarmerProfilePageState();
}

class _FarmerProfilePageState extends State<FarmerProfilePage> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();

  bool _isEditing = false;
  String? _selectedProfileImage = 'assets/avatars/avatar1.png';

  // Firestore reference for the user's profile
  final String userId = 'your-user-id'; // Replace this with the actual user ID

  @override
  void initState() {
    super.initState();
    _fetchProfileData();
  }

  // Fetch profile data from Firestore and populate the fields
  void _fetchProfileData() async {
    try {
      DocumentSnapshot userDoc =
          await FirebaseFirestore.instance
              .collection(
                'FarmerProfiles',
              ) // Assuming the collection is 'FarmerProfiles'
              .doc(userId) // Fetching the profile using the user's ID
              .get();

      if (userDoc.exists) {
        var data = userDoc.data() as Map<String, dynamic>;
        setState(() {
          _nameController.text = data['name'] ?? '';
          _emailController.text = data['email'] ?? '';
          _phoneController.text = data['phone'] ?? '';
          _addressController.text = data['address'] ?? '';
          _selectedProfileImage =
              data['profileImage'] ?? 'assets/clientavatars/avatar1.png';
        });
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to load profile data: $e')),
      );
    }
  }

  // Save the profile data to Firestore
  void _saveProfileData() async {
    final Map<String, dynamic> profileData = {
      'name': _nameController.text,
      'email': _emailController.text,
      'phone': _phoneController.text,
      'address': _addressController.text,
      'profileImage': _selectedProfileImage,
    };

    try {
      await FirebaseFirestore.instance
          .collection('FarmerProfiles')
          .doc(userId) // Update the current user's profile
          .set(profileData, SetOptions(merge: true));

      setState(() {
        _isEditing = false;
      });

      // Show success message
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Profile updated successfully!')),
      );
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Failed to save profile: $e')));
    }
  }

  void _showProfileImagePicker() {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return Container(
          padding: const EdgeInsets.all(16),
          height: 300,
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(15)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Select a Profile Image',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.teal,
                ),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: GridView.builder(
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    mainAxisSpacing: 10,
                    crossAxisSpacing: 10,
                  ),
                  itemCount: 4, // Number of profile images
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          _selectedProfileImage =
                              'assets/avatars/avatar${index + 1}.png';
                        });
                        Navigator.pop(context);
                      },
                      child: CircleAvatar(
                        radius: 50,
                        backgroundImage: AssetImage(
                          'assets/avatars/avatar${index + 1}.png',
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _addressController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        flexibleSpace: Container(
          decoration: const BoxDecoration(color: Colors.transparent),
        ),

        actions: [
          IconButton(
            icon: Icon(_isEditing ? Icons.check : Icons.edit),
            onPressed: () {
              if (_isEditing) {
                // Save the data
                _saveProfileData();
              } else {
                setState(() {
                  _isEditing = true;
                });
              }
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 20),
            GestureDetector(
              onTap: _isEditing ? _showProfileImagePicker : null,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                height: 120,
                width: 120,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  boxShadow:
                      _isEditing
                          ? [
                            BoxShadow(
                              color: Colors.grey.shade400,
                              blurRadius: 10,
                              spreadRadius: 5,
                            ),
                          ]
                          : null,
                ),
                child: CircleAvatar(
                  backgroundImage: AssetImage(_selectedProfileImage!),
                ),
              ),
            ),
            const SizedBox(height: 20),
            _buildProfileForm(),
          ],
        ),
      ),
      floatingActionButton:
          !_isEditing
              ? null
              : FloatingActionButton(
                backgroundColor: Colors.teal,
                onPressed: _saveProfileData,
                child: const Icon(Icons.save),
              ),
    );
  }

  Widget _buildProfileForm() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          _buildEditableCard('Name', _nameController),
          _buildEditableCard('Email', _emailController),
          _buildEditableCard('Phone', _phoneController),
          _buildEditableCard('Address', _addressController),
        ],
      ),
    );
  }

  Widget _buildEditableCard(String label, TextEditingController controller) {
    return Card(
      elevation: 4,
      margin: const EdgeInsets.symmetric(vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: ListTile(
        title: TextField(
          controller: controller,
          enabled: _isEditing,
          decoration: InputDecoration(
            labelText: label,
            border: InputBorder.none,
            labelStyle: const TextStyle(color: Colors.teal),
          ),
        ),
      ),
    );
  }
}
