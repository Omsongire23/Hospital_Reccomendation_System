import 'dart:developer';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_application_1/Snackbar.dart';
import 'package:flutter_application_1/clientside/darshboardclient.dart';
import 'package:flutter_application_1/farmersSide/dashboard.dart';
import 'package:flutter_application_1/logins/userRegister.dart';
import 'package:google_fonts/google_fonts.dart';

class userLoginScreen extends StatefulWidget {
  const userLoginScreen({super.key});

  @override
  State<userLoginScreen> createState() => _userLoginScreenState();
}

class _userLoginScreenState extends State<userLoginScreen>
    with TickerProviderStateMixin {
  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  bool _showPassword = false;
  bool _isLoading = false;

  late AnimationController _logoController;
  late Animation<double> _logoAnimation;

  late AnimationController _formController;
  late Animation<Offset> _formOffset;

  @override
  void initState() {
    super.initState();

    _logoController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );
    _logoAnimation = CurvedAnimation(
      parent: _logoController,
      curve: Curves.easeIn,
    );

    _formController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );
    _formOffset = Tween<Offset>(
      begin: const Offset(0, 1),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _formController, curve: Curves.easeOut));

    _logoController.forward();
    Future.delayed(
      const Duration(milliseconds: 500),
      () => _formController.forward(),
    );
  }

  @override
  void dispose() {
    _logoController.dispose();
    _formController.dispose();
    email.dispose();
    password.dispose();
    super.dispose();
  }

  Future<void> _showUserTypeDialog(BuildContext context, User user) async {
    if (!mounted) return;

    return showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            "Select User Type",
            style: GoogleFonts.dmSans(fontWeight: FontWeight.bold),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(
                  Icons.admin_panel_settings,
                  color: Colors.green,
                ),
                title: Text("Admin", style: GoogleFonts.dmSans()),
                onTap: () {
                  Navigator.pop(context);
                  if (mounted) {
                    Navigator.of(context).pushReplacement(
                      MaterialPageRoute(
                        builder:
                            (context) =>
                                FarmerMarketScreen(email: user.email ?? ''),
                      ),
                    );
                  }
                },
              ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.person, color: Colors.blue),
                title: Text("Client", style: GoogleFonts.dmSans()),
                onTap: () {
                  Navigator.pop(context);
                  if (mounted) {
                    Navigator.of(context).pushReplacement(
                      MaterialPageRoute(
                        builder: (context) => ClientMarketPage(),
                      ),
                    );
                  }
                },
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromRGBO(242, 250, 245, 1),
      body: SingleChildScrollView(
        child: Column(
          children: [
            FadeTransition(
              opacity: _logoAnimation,
              child: Padding(
                padding: const EdgeInsets.only(top: 100),
                child: Center(
                  child: Column(
                    children: [
                      Image.asset("assets/Group.png", height: 100, width: 80),
                      const SizedBox(height: 20),
                      Text(
                        "Welcome Back!",
                        style: GoogleFonts.dmSans(
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        "Login to continue",
                        style: GoogleFonts.dmSans(
                          fontSize: 16,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 30),
            SlideTransition(
              position: _formOffset,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildTextLabel("Email"),
                    _buildInputField(email, "Enter your email", false),
                    const SizedBox(height: 20),
                    _buildTextLabel("Password"),
                    _buildInputField(password, "Enter your password", true),
                    Align(
                      alignment: Alignment.centerRight,
                      child: Text(
                        "Forgot Password?",
                        style: GoogleFonts.dmSans(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    _buildLoginButton(),
                    const SizedBox(height: 40),
                    _buildSignUpLink(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextLabel(String label) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Text(
        label,
        style: GoogleFonts.dmSans(
          fontSize: 18,
          fontWeight: FontWeight.w700,
          color: Colors.black87,
        ),
      ),
    );
  }

  Widget _buildInputField(
    TextEditingController controller,
    String hint,
    bool isPassword,
  ) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: const [BoxShadow(color: Colors.grey, blurRadius: 2)],
      ),
      child: TextField(
        controller: controller,
        obscureText: isPassword && !_showPassword,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: GoogleFonts.dmSans(fontSize: 16, color: Colors.grey),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 18,
          ),
          suffixIcon:
              isPassword
                  ? GestureDetector(
                    onTap: () {
                      if (mounted) {
                        setState(() => _showPassword = !_showPassword);
                      }
                    },
                    child: Icon(
                      _showPassword ? Icons.visibility_off : Icons.visibility,
                    ),
                  )
                  : null,
        ),
      ),
    );
  }

  Widget _buildLoginButton() {
    return ElevatedButton(
      onPressed: _isLoading ? null : _handleLogin,
      style: ElevatedButton.styleFrom(
        backgroundColor: const Color.fromRGBO(83, 177, 117, 1),
        minimumSize: const Size.fromHeight(50),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
      child:
          _isLoading
              ? const CircularProgressIndicator(color: Colors.white)
              : Text(
                "Log In",
                style: GoogleFonts.dmSans(
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
    );
  }

  Future<void> _handleLogin() async {
    if (email.text.trim().isEmpty || password.text.trim().isEmpty) {
      if (mounted) {
        CustomSnackbar.showCustomSnackbar(
          message: "Please enter both email and password",
          context: context,
        );
      }
      return;
    }

    if (mounted) {
      setState(() => _isLoading = true);
    }

    try {
      UserCredential userCredential = await _firebaseAuth
          .signInWithEmailAndPassword(
            email: email.text.trim(),
            password: password.text.trim(),
          )
          .whenComplete(() {
            if (mounted) {
              setState(() => _isLoading = false);
            }
          });

      log("Login successful: ${userCredential.user!.email}");

      if (!mounted) return;

      // You can choose to show the dialog or navigate directly
      // Option 1: Show user type dialog
      // await _showUserTypeDialog(context, userCredential.user!);

      // Option 2: Navigate directly to client page
      Navigator.of(
        context,
      ).pushReplacement(MaterialPageRoute(builder: (_) => ClientMarketPage()));
    } on FirebaseAuthException catch (error) {
      log("Login error: ${error.code}");
      if (mounted) {
        setState(() => _isLoading = false);
        String errorMessage = switch (error.code) {
          'user-not-found' => "No user found with this email",
          'wrong-password' => "Incorrect password",
          'invalid-email' => "Invalid email format",
          _ => error.message ?? "Login failed",
        };
        CustomSnackbar.showCustomSnackbar(
          message: errorMessage,
          context: context,
        );
      }
    } catch (error) {
      log("Unexpected error: $error");
      if (mounted) {
        setState(() => _isLoading = false);
        CustomSnackbar.showCustomSnackbar(
          message: "An unexpected error occurred",
          context: context,
        );
      }
    }
  }

  Widget _buildSignUpLink() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          "Don't have an account?",
          style: GoogleFonts.dmSans(color: Colors.grey[700], fontSize: 16),
        ),
        const SizedBox(width: 6),
        GestureDetector(
          onTap: () {
            if (mounted) {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const userRegisterScreen()),
              );
            }
          },
          child: Text(
            "Sign up",
            style: GoogleFonts.dmSans(
              color: Colors.green[700],
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ],
    );
  }
}
