import 'dart:developer';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_application_1/Snackbar.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shimmer/shimmer.dart';

class adminRegisterScreen extends StatefulWidget {
  const adminRegisterScreen({super.key});

  @override
  State<adminRegisterScreen> createState() => _adminRegisterScreenState();
}

class _adminRegisterScreenState extends State<adminRegisterScreen>
    with SingleTickerProviderStateMixin {
  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();
  TextEditingController confirmPassword = TextEditingController();
  bool _showPassword = false;
  late AnimationController _animationController;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    );
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 1),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    email.dispose();
    password.dispose();
    confirmPassword.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Expanded(
        child: Container(
          decoration: const BoxDecoration(color: Colors.white),
          child: SingleChildScrollView(
            child: Column(
              children: [
                SizedBox(height: 40),
                Center(
                  child: Text(
                    "Welcome to Efarm",
                    style: GoogleFonts.dmSans(
                      fontSize: 35,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xFF53B175),
                    ),
                  ),
                ),
                const SizedBox(height: 60),
                FadeInImage(
                  placeholder: const AssetImage(
                    "assets/placeholder.png",
                  ), // optional
                  image: const AssetImage("assets/Group.png"),
                  height: 100,
                ),
                Center(
                  child: Text(
                    "Sign Up",
                    style: GoogleFonts.dmSans(
                      fontSize: 35,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xFF53B175),
                    ),
                  ),
                ),

                const SizedBox(height: 40),
                SlideTransition(
                  position: _slideAnimation,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 30),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildLabel("Register Here"),
                        _buildSubLabel("Enter your email and password"),
                        const SizedBox(height: 30),
                        _buildLabel("Email"),
                        _buildTextField(email, "Enter your email"),
                        const SizedBox(height: 20),
                        _buildLabel("Password"),
                        _buildPasswordField(password),
                        const SizedBox(height: 20),
                        _buildLabel("Confirm Password"),
                        _buildPasswordField(confirmPassword),
                        const SizedBox(height: 30),
                        _buildSignupButton(context),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLabel(String text) => Text(
    text,
    style: GoogleFonts.dmSans(
      fontSize: 20,
      fontWeight: FontWeight.w700,
      color: const Color.fromARGB(255, 12, 12, 12),
    ),
  );

  Widget _buildSubLabel(String text) => Text(
    text,
    style: GoogleFonts.dmSans(
      fontSize: 16,
      fontWeight: FontWeight.w400,
      color: Colors.white70,
    ),
  );

  Widget _buildTextField(TextEditingController controller, String hint) =>
      Container(
        margin: const EdgeInsets.only(top: 10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 6)],
        ),
        child: TextField(
          controller: controller,
          style: const TextStyle(fontSize: 16),
          decoration: InputDecoration(
            hintText: hint,
            contentPadding: const EdgeInsets.symmetric(horizontal: 16),
            border: InputBorder.none,
          ),
        ),
      );

  Widget _buildPasswordField(TextEditingController controller) => Container(
    margin: const EdgeInsets.only(top: 10),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 6)],
    ),
    child: TextField(
      controller: controller,
      obscureText: !_showPassword,
      style: const TextStyle(fontSize: 16),
      decoration: InputDecoration(
        hintText: "Enter your password",
        suffixIcon: IconButton(
          icon: Icon(
            _showPassword ? Icons.visibility_off : Icons.visibility,
            color: Colors.grey,
          ),
          onPressed: () {
            setState(() {
              _showPassword = !_showPassword;
            });
          },
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16),
        border: InputBorder.none,
      ),
    ),
  );

  Widget _buildSignupButton(BuildContext context) => Shimmer.fromColors(
    baseColor: const Color(0xFF53B175),
    highlightColor: Colors.white,
    child: ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.transparent,
        shadowColor: Colors.transparent,
        fixedSize: const Size(double.infinity, 55),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
      onPressed: () async {
        if (email.text.trim().isEmpty ||
            password.text.trim().isEmpty ||
            confirmPassword.text.trim().isEmpty) {
          CustomSnackbar.showCustomSnackbar(
            message: "Please fill all fields",
            context: context,
          );
          return;
        }

        if (password.text.trim() != confirmPassword.text.trim()) {
          CustomSnackbar.showCustomSnackbar(
            message: "Passwords do not match",
            context: context,
          );
          return;
        }

        try {
          UserCredential userCredential = await FirebaseAuth.instance
              .createUserWithEmailAndPassword(
                email: email.text.trim(),
                password: password.text.trim(),
              );
          log("User registered: ${userCredential.user!.email}");
          CustomSnackbar.showCustomSnackbar(
            message: "Registration Successful!",
            context: context,
          );
          Navigator.of(context).pop();
        } catch (e) {
          log("Registration error: $e");
          CustomSnackbar.showCustomSnackbar(
            message: "Registration Failed",
            context: context,
          );
        }
      },
      child: Text(
        "Sign Up",
        style: GoogleFonts.dmSans(
          fontSize: 24,
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),
      ),
    ),
  );
}
